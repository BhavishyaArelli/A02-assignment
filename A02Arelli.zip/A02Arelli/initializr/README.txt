--A02--

My project includes the concept of placing an online order for different brands of televisions. Here the user can make a choice among different models and place an order, which inturn will return the price.  